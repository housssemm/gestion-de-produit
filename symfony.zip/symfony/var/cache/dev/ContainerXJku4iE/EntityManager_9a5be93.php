<?php

namespace ContainerXJku4iE;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'src'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder69ccd = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializerfe611 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicProperties055f4 = [
        
    ];

    public function getConnection()
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'getConnection', array(), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'getMetadataFactory', array(), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'getExpressionBuilder', array(), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'beginTransaction', array(), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->beginTransaction();
    }

    public function getCache()
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'getCache', array(), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->getCache();
    }

    public function transactional($func)
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'transactional', array('func' => $func), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'wrapInTransaction', array('func' => $func), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'commit', array(), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->commit();
    }

    public function rollback()
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'rollback', array(), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'getClassMetadata', array('className' => $className), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'createQuery', array('dql' => $dql), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'createNamedQuery', array('name' => $name), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'createQueryBuilder', array(), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'flush', array('entity' => $entity), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'clear', array('entityName' => $entityName), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->clear($entityName);
    }

    public function close()
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'close', array(), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->close();
    }

    public function persist($entity)
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'persist', array('entity' => $entity), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'remove', array('entity' => $entity), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'refresh', array('entity' => $entity), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'detach', array('entity' => $entity), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'merge', array('entity' => $entity), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'getRepository', array('entityName' => $entityName), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'contains', array('entity' => $entity), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'getEventManager', array(), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'getConfiguration', array(), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'isOpen', array(), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'getUnitOfWork', array(), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'getProxyFactory', array(), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'initializeObject', array('obj' => $obj), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'getFilters', array(), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'isFiltersStateClean', array(), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'hasFilters', array(), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return $this->valueHolder69ccd->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializerfe611 = $initializer;

        return $instance;
    }

    public function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config)
    {
        static $reflection;

        if (! $this->valueHolder69ccd) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder69ccd = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder69ccd->__construct($conn, $config);
    }

    public function & __get($name)
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, '__get', ['name' => $name], $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        if (isset(self::$publicProperties055f4[$name])) {
            return $this->valueHolder69ccd->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder69ccd;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder69ccd;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, '__set', array('name' => $name, 'value' => $value), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder69ccd;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder69ccd;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, '__isset', array('name' => $name), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder69ccd;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder69ccd;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, '__unset', array('name' => $name), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder69ccd;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder69ccd;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, '__clone', array(), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        $this->valueHolder69ccd = clone $this->valueHolder69ccd;
    }

    public function __sleep()
    {
        $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, '__sleep', array(), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;

        return array('valueHolder69ccd');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializerfe611 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializerfe611;
    }

    public function initializeProxy() : bool
    {
        return $this->initializerfe611 && ($this->initializerfe611->__invoke($valueHolder69ccd, $this, 'initializeProxy', array(), $this->initializerfe611) || 1) && $this->valueHolder69ccd = $valueHolder69ccd;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder69ccd;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder69ccd;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
