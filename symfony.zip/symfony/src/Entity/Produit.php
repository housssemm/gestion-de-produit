<?php

namespace App\Entity;

use App\Repository\ProduitRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: ProduitRepository::class)]
class Produit
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $NameP = null;

    #[ORM\Column]
    private ?int $Quantity = null;

    #[ORM\Column]
    private ?float $WeigthP = null;

    #[ORM\Column]
    private ?int $PriceP = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNameP(): ?string
    {
        return $this->NameP;
    }

    public function setNameP(string $NameP): self
    {
        $this->NameP = $NameP;

        return $this;
    }

    public function getQuantity(): ?int
    {
        return $this->Quantity;
    }

    public function setQuantity(int $Quantity): self
    {
        $this->Quantity = $Quantity;

        return $this;
    }

    public function getWeigthP(): ?float
    {
        return $this->WeigthP;
    }

    public function setWeigthP(float $WeigthP): self
    {
        $this->WeigthP = $WeigthP;

        return $this;
    }

    public function getPriceP(): ?int
    {
        return $this->PriceP;
    }

    public function setPriceP(int $PriceP): self
    {
        $this->PriceP = $PriceP;

        return $this;
    }
}
