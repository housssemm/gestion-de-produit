<?php
// src/Controller/LuckyController.php
namespace App\Controller;

use App\Entity\Produit;
use App\Form\produitType;
use App\Repository\ProduitRepository;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class LuckyController extends AbstractController
{
     private $ProduitRepository ;

     public function __construct(ProduitRepository $ProduitRepository){
      $this->ProduitRepository = $ProduitRepository;
     }
       /**
    * @Route("/",name="produit_list")
   */
    public function index(){
     $produits= $this-> ProduitRepository->findAll();
        return $this->render ('home.html.twig',["prod"=>$produits]);
    }
    /**
    * @Route("/produit/{id}",name="showProd")
   */
    public function showProd($id)
    {
        $produit= $this->ProduitRepository->find($id);
        return $this->render ('show.html.twig',["prod"=>$produit]);
    }
     /**
    * @Route("/ajouter/produit",name="creatproduit")
   */
    public function creatproduit  (Request $request){
        $produit = new Produit();
       

        $form = $this->createForm(produitType::class, $produit);
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
         
            $produit = $form->getData();
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($produit);
            $entityManager->flush();
           
            
            return $this->redirectToRoute('produit_list');
        }

        return $this->renderForm('add.html.twig', [
            'form' => $form,
        ]);    }
         /**
    * @Route("/edit/prodit/{id}",name="editproduit")
   */
    public function editproduit  (produit $produit ,Request $request){
      
       

        $form = $this->createForm(produitType::class, $produit);
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
             
            $produit = $form->getData();
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($produit);
            $entityManager->flush();
         
            
            return $this->redirectToRoute('produit_list');
        }

        return $this->renderForm('edit.html.twig', [
            'form' => $form,
        ]);    }
      /**
    * @Route("/delete/prodit/{id}",name="deleteproduit")
   */
  public function deleteproduit  (produit $produit){
         
        
        $entityManager = $this->getDoctrine()->getManager();
        $entityManager->remove($produit);
        $entityManager->flush();
     
        
        return $this->redirectToRoute('produit_list');
    

    }
} 