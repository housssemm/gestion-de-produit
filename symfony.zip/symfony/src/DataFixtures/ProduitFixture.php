<?php

namespace App\DataFixtures;

use App\Entity\Produit;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;

class ProduitFixture extends Fixture
{
    public function load(ObjectManager $manager): void
    {
        for ($i = 1 ; $i <= 10 ; $i++){
          $Produit=new Produit();
          $Produit->setNameP('produit name : '.$i);
          $Produit->setQuantity($i);
          $Produit->setWeigthP( $i);
          $Produit->setPriceP($i);
          $manager->persist($Produit);
        }
        
        $manager->flush();
    }
}
